// sdk/python/README.md placeholder
