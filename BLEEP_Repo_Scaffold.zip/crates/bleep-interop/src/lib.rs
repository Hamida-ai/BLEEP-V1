// crates/bleep-interop/src/lib.rs placeholder
