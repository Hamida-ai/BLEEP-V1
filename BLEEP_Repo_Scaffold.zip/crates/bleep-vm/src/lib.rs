// crates/bleep-vm/src/lib.rs placeholder
