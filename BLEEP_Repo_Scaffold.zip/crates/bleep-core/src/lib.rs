// crates/bleep-core/src/lib.rs placeholder
