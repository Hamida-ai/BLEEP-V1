// crates/bleep-auth/src/lib.rs placeholder
