// docs/architecture.md placeholder
