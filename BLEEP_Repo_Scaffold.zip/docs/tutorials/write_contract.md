// docs/tutorials/write_contract.md placeholder
