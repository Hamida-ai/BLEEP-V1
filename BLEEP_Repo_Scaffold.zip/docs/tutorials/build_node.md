// docs/tutorials/build_node.md placeholder
