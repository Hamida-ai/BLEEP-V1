// docs/glossary.md placeholder
