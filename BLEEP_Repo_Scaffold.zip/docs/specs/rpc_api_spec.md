// docs/specs/rpc_api_spec.md placeholder
