// docs/specs/state_transition.md placeholder
