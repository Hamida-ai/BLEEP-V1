// docs/governance.md placeholder
